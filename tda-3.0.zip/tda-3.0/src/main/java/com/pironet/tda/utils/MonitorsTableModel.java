/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.pironet.tda.utils;

//import org.jdesktop.swingx.treetable.AbstractTreeTableModel;

/**
 * @author irockel
 */
public class MonitorsTableModel {//extends AbstractTreeTableModel {

    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object getValueAt(Object arg0, int arg1) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object getChild(Object parent, int index) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int getChildCount(Object parent) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int getIndexOfChild(Object parent, Object child) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
